def fun():
	return "this is fun in f1.py"
print "fun clling in f1:", fun()