
print "name value: ",__name__

def fun():
	return "this is fun in f4 modified..................................."
def fun1():
	return "this is fun1 in f4"

def main():
	print ("some starting statements")
	print (fun())
	print (fun1())
	print ("other statements in program")
	print ("program ended")

if __name__ == "__main__":
	main()