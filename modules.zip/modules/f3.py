print "some starting statements"
def fun():
	return "this is fun in f3"
def fun1():
	return "this is fun1 in f3"
print fun()
print fun1()
print "other statements in program"
print "program ended"